var typed = new Typed(".text",
{
    strings:["Engineering Student","Problem Solver", "Web Developer"],
    typeSpeed:100,
    backSpeed:100,
    backDeleay:1000,
    loop:true
})